#!/usr/bin/env node
import { promises as fs } from 'fs';
import path from 'path';

const SRC_DIR = path.resolve(process.cwd(), 'src');
const DIST_DIR = path.resolve(process.cwd(), 'dist');
const DEST_ROOT = path.join(DIST_DIR, 'src');

async function ensureDir(dir) {
  await fs.mkdir(dir, { recursive: true });
}

async function copyJsonFiles(srcDir, destDir) {
  const entries = await fs.readdir(srcDir, { withFileTypes: true });
  for (const entry of entries) {
    const srcPath = path.join(srcDir, entry.name);
    const destPath = path.join(destDir, entry.name);
    if (entry.isDirectory()) {
      await copyJsonFiles(srcPath, destPath);
    } else if (entry.isFile() && entry.name.toLowerCase().endsWith('.json')) {
      await ensureDir(path.dirname(destPath));
      await fs.copyFile(srcPath, destPath);
    }
  }
}

async function main() {
  try {
    // If src is missing, nothing to copy
    await fs.stat(SRC_DIR).catch(() => null);
    const exists = await fs
      .access(SRC_DIR)
      .then(() => true)
      .catch(() => false);
    if (!exists) return;
    await copyJsonFiles(SRC_DIR, DEST_ROOT);
    // Also copy any top-level JSONs under mcp/src directly into dist (keeping structure)
  } catch (err) {
    console.error('Failed to copy JSON assets:', err);
    process.exitCode = 1;
  }
}

main();
