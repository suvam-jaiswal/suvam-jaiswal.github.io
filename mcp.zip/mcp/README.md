# Platform UI MCP Server

A Model Context Protocol (MCP) server that provides intelligent access to the Mosaic Design System (MDS) Vue component library documentation. This server enables AI agents like Claude to access accurate, up-to-date component documentation without hallucination.

## Features

- 🔍 **Intelligent Component Search**: Fuzzy search with semantic matching for finding the right components
- 📚 **Comprehensive Documentation**: Access to props, events, slots, TypeScript definitions, and examples
- 🎨 **Utility Classes**: Browse and search MDS utility classes for styling
- 📦 **Progressive Discovery**: Efficient two-step process (search → details) for optimal performance
- 🛠️ **Developer Tools**: Prompts for building components and reviewing code

## Installation

```bash
npm install
npm run build
```

## Usage with Claude Desktop

Add to your Claude Desktop configuration (`~/Library/Application Support/Claude/claude_desktop_config.json`):

```json
{
  "mcpServers": {
    "platform-ui": {
      "command": "node",
      "args": ["/path/to/components-vue/mcp/dist/index.js"]
    }
  }
}
```

## Available Tools

### 1. `searchComponents`
Search for MDS Vue components by name, type, or functionality.

**Input:**
- `query` (string): Search query
- `limit` (number, optional): Maximum results (default: 10)

**Example:**
```json
{
  "query": "form input",
  "limit": 5
}
```

### 2. `getComponentDocs`
Get detailed documentation for specific components.

**Input:**
- `components` (string[]): Array of component names
- `includeExamples` (boolean, optional): Include code examples (default: true)

**Example:**
```json
{
  "components": ["Button", "Card", "Dialog"],
  "includeExamples": true
}
```

### 3. `searchUtilities`
Search for MDS utility classes by category or class name.

**Input:**
- `query` (string): Search query
- `limit` (number, optional): Maximum categories (default: 5)
- `includeExamples` (boolean, optional): Include examples (default: true)

**Example:**
```json
{
  "query": "spacing",
  "limit": 3
}
```

### 4. `getIcons`
Get a list of all available MDS icons.

**Input:**
- `query` (string, optional): Filter icons by name
- `page` (number, optional): Page number (default: 1)
- `pageSize` (number, optional): Icons per page (default: 50)

**Example:**
```json
{
  "query": "user",
  "page": 1,
  "pageSize": 20
}
```

## Available Resources

### Component Resources
- `mds://components/catalog` - Complete catalog of all components
- `mds://components/{ComponentName}` - Detailed docs for specific component

### Utility Resources
- `mds://utilities/catalog` - All utility classes organized by category

## Available Prompts

### `buildComponent`
Generate complete Vue component implementations using MDS components.

**Arguments:**
- `requirements` (string): Component requirements
- `components` (string[], optional): Specific components to use
- `includeUtilities` (boolean, optional): Include utility classes

## Development Workflow

### Typical AI Agent Workflow

1. **User Request**: "Create a card with tabs and buttons"
2. **Search Components**: Agent calls `searchComponents("card tabs button")`
3. **Fetch Documentation**: Agent calls `getComponentDocs(["Card", "TabView", "Button"])`
4. **Search Utilities**: Agent calls `searchUtilities("spacing flex")`
5. **Generate Code**: Agent uses the documentation to write accurate code

### Example Session

```typescript
// 1. Search for components
const searchResults = await mcp.callTool('searchComponents', {
  query: 'data table',
  limit: 5
});

// 2. Get detailed docs
const docs = await mcp.callTool('getComponentDocs', {
  components: ['DataTable', 'Column'],
  includeExamples: true
});

// 3. Search for utilities
const utilities = await mcp.callTool('searchUtilities', {
  query: 'table spacing',
  limit: 3
});

// 4. Use prompt to build component
const prompt = await mcp.getPrompt('buildComponent', {
  requirements: 'A data table with sorting, filtering, and pagination',
  components: ['DataTable', 'Column', 'Button'],
  includeUtilities: true
});
```

## Architecture

```
mcp/
├── src/
│   ├── tools/              # MCP tool implementations
│   │   ├── searchComponents.ts
│   │   ├── getComponentDocs.ts
│   │   ├── searchUtilities.ts
│   │   └── getIcons.ts
│   ├── resources/          # MCP resource providers
│   │   ├── componentCatalog.ts
│   │   ├── componentDetail.ts
│   │   └── utilityCatalog.ts
│   ├── prompts/            # MCP prompt templates
│   │   └── buildComponent.ts
│   ├── data/               # Data loading and formatting
│   │   ├── loader.ts
│   │   └── formatter.ts
│   ├── utils/              # Utilities
│   │   └── search.ts
│   ├── components/         # Component JSON metadata
│   └── utilities.json      # Utility classes metadata
├── index.ts                # Main server entry point
└── package.json
```

## Features in Detail

### Fuzzy Search
The server uses intelligent fuzzy matching that:
- Handles typos and partial matches
- Supports semantic matching (e.g., "modal" → Dialog, Drawer, Popover)
- Weighs exact matches higher than partial matches
- Searches both component names and descriptions

### Progressive Documentation
- **Overview First**: Initial search returns brief component summaries
- **Details on Demand**: Full documentation fetched only when needed
- **Efficient Context**: Prevents token waste by selective documentation loading

### Component Categorization
Components are automatically categorized into:
- **Form**: Input fields, selections, date pickers
- **Data**: Tables, lists, trees
- **Overlay**: Modals, dialogs, tooltips
- **Navigation**: Menus, breadcrumbs, tabs
- **Display**: Cards, panels, accordions
- **Feedback**: Messages, progress, loading
- **Media**: Images, charts, carousels

## Troubleshooting

### Server not starting
- Ensure all dependencies are installed: `npm install`
- Build the project: `npm run build`
- Check Node.js version (requires v18+)

### Components not loading
- Verify JSON files exist in `src/components/`
- Check console output for loading errors
- Ensure proper file permissions

### Search not finding components
- Try simpler search terms
- Use component name directly
- Check if component exists in catalog

## Contributing

1. Add new component JSON files to `src/components/`
2. Update utility classes in `src/utilities.json`
3. Extend search patterns in `src/utils/search.ts`
4. Add new tools/resources/prompts as needed
5. Build and test: `npm run build`

## License

ISC