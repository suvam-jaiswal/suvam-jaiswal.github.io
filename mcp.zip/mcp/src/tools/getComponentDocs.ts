import { z } from 'zod';
import type { Tool } from '@modelcontextprotocol/sdk/types.js';
import { dataLoader } from '../data/loader.js';
import { ResponseFormatter } from '../data/formatter.js';

export const getComponentDocsInputSchema = z.object({
  components: z.array(z.string()).describe('Array of component names to get documentation for'),
  includeExamples: z.boolean().optional().default(true).describe('Whether to include code examples'),
});

export type GetComponentDocsInput = z.infer<typeof getComponentDocsInputSchema>;

export async function handleGetComponentDocs(input: GetComponentDocsInput) {
  const { components, includeExamples } = input;
  
  const docs: Record<string, string> = {};
  const notFound: string[] = [];
  
  for (const componentName of components) {
    const component = dataLoader.getComponent(componentName);
    
    if (component) {
      // Filter out examples if not requested
      const componentData = includeExamples ? component : {
        ...component,
        examples: [],
      };
      
      docs[componentName] = ResponseFormatter.formatComponentDetailed(componentData);
    } else {
      notFound.push(componentName);
    }
  }
  
  const response = {
    requestedComponents: components,
    foundComponents: Object.keys(docs),
    notFoundComponents: notFound,
    documentation: docs,
  };
  
  return {
    content: [{
      type: 'text',
      text: JSON.stringify(response, null, 2),
    }],
  };
}

export const getComponentDocsTool: Tool = {
  name: 'getComponentDocs',
  title: 'Get Component Documentation',
  description: 'Get detailed documentation for specific MDS Vue components including props, events, slots, TypeScript definitions, and usage examples.',
  inputSchema: {
    type: 'object',
    properties: {
      components: {
        type: 'array',
        items: {
          type: 'string',
        },
        description: 'Array of component names to get documentation for',
      },
      includeExamples: {
        type: 'boolean',
        description: 'Whether to include code examples',
        default: true,
      },
    },
    required: ['components'],
  },
};