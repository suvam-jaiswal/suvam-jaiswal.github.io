import { z } from 'zod';
import type { Tool } from '@modelcontextprotocol/sdk/types.js';
import { dataLoader } from '../data/loader.js';
import { searchUtilities } from '../utils/search.js';
import { ResponseFormatter } from '../data/formatter.js';

export const searchUtilitiesInputSchema = z.object({
  query: z.string().describe('Search query for utility classes (category or class name)'),
  limit: z.number().optional().default(5).describe('Maximum number of categories to return'),
  includeExamples: z.boolean().optional().default(true).describe('Whether to include usage examples'),
});

export type SearchUtilitiesInput = z.infer<typeof searchUtilitiesInputSchema>;

export async function handleSearchUtilities(input: SearchUtilitiesInput) {
  const { query, limit, includeExamples } = input;
  
  // Get all utilities
  const allUtilities = dataLoader.getAllUtilities();
  
  // Search with fuzzy matching
  const searchResults = searchUtilities(query, allUtilities);
  
  // Limit results
  const limitedResults = searchResults.slice(0, limit);
  
  // Format response
  const formattedResults = limitedResults.map(({ item, score }) => {
    const utilityData = includeExamples ? item : {
      ...item,
      examples: [],
    };
    
    return {
      category: item.category,
      score: Math.round(score * 100),
      classCount: item.classes?.length || 0,
      documentation: ResponseFormatter.formatUtilityCategory(utilityData),
    };
  });
  
  const response = {
    query,
    totalResults: searchResults.length,
    showing: limitedResults.length,
    utilities: formattedResults,
  };
  
  return {
    content: [{
      type: 'text',
      text: JSON.stringify(response, null, 2),
    }],
  };
}

export const searchUtilitiesTool: Tool = {
  name: 'searchUtilities',
  title: 'Search Utility Classes',
  description: 'Search for MDS utility classes by category or class name. Returns matching utility classes with examples.',
  inputSchema: {
    type: 'object',
    properties: {
      query: {
        type: 'string',
        description: 'Search query for utility classes (category or class name)',
      },
      limit: {
        type: 'number',
        description: 'Maximum number of categories to return',
        default: 5,
      },
      includeExamples: {
        type: 'boolean',
        description: 'Whether to include usage examples',
        default: true,
      },
    },
    required: ['query'],
  },
};