import { z } from 'zod';

import type { Tool } from '@modelcontextprotocol/sdk/types.js';

import { dataLoader } from '../data/loader.js';

export const getIconsInputSchema = z.object({
  query: z.string().optional().describe('Optional search query to filter icons by name'),
  page: z.number().optional().default(1).describe('Page number for pagination'),
  pageSize: z.number().optional().default(50).describe('Number of icons per page'),
});

export type GetIconsInput = z.infer<typeof getIconsInputSchema>;

export async function handleGetIcons(input: GetIconsInput) {
  const { query, page = 1, pageSize = 50 } = input;

  // Get all icons
  const allIcons = dataLoader.getIcons();

  // Filter icons if query is provided
  let filteredIcons = allIcons;
  if (query) {
    const searchTerm = query.toLowerCase();
    filteredIcons = allIcons.filter((icon: string) => 
      icon.toLowerCase().includes(searchTerm)
    );
  }

  // Calculate pagination
  const totalIcons = filteredIcons.length;
  const totalPages = Math.ceil(totalIcons / pageSize);
  const startIndex = (page - 1) * pageSize;
  const endIndex = startIndex + pageSize;
  
  // Get paginated icons
  const paginatedIcons = filteredIcons.slice(startIndex, endIndex);

  const response = {
    query: query || null,
    totalIcons,
    totalPages,
    currentPage: page,
    pageSize,
    showing: paginatedIcons.length,
    icons: paginatedIcons,
  };

  return {
    content: [{
      type: 'text',
      text: JSON.stringify(response, null, 2),
    }],
  };
}

export const getIconsTool: Tool = {
  name: 'getIcons',
  title: 'Get Icons',
  description: 'Get a list of all available MDS icons. Supports optional search filtering and pagination.',
  inputSchema: {
    type: 'object',
    properties: {
      query: {
        type: 'string',
        description: 'Optional search query to filter icons by name',
      },
      page: {
        type: 'number',
        description: 'Page number for pagination',
        default: 1,
      },
      pageSize: {
        type: 'number',
        description: 'Number of icons per page',
        default: 50,
      },
    },
  },
};