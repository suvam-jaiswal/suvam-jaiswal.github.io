import type { Tool } from '@modelcontextprotocol/sdk/types.js';
import { dataLoader } from '../data/loader.js';

export async function handleListComponents() {
  const names = dataLoader.getComponentNames();
  return {
    content: [
      {
        type: 'text',
        text: JSON.stringify(names, null, 2),
      },
    ],
  };
}

export const listComponentsTool: Tool = {
  name: 'listComponents',
  title: 'List Components',
  description: 'Return the names of all available design system components.',
  inputSchema: {
    type: 'object',
    properties: {},
  },
};

