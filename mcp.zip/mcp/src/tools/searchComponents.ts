import { z } from 'zod';

import type { Tool } from '@modelcontextprotocol/sdk/types.js';

import { ResponseFormatter } from '../data/formatter.js';
import { dataLoader } from '../data/loader.js';
import { searchComponents } from '../utils/search.js';

export const searchComponentsInputSchema = z.object({
  query: z.string().describe('Search query for components (name, type, or description)'),
  limit: z.number().optional().default(10).describe('Maximum number of results to return'),
});

export type SearchComponentsInput = z.infer<typeof searchComponentsInputSchema>;

export async function handleSearchComponents(input: SearchComponentsInput) {
  const { query, limit } = input;

  // Get all components
  const allComponents = dataLoader.getAllComponents();

  // Search with fuzzy matching
  const searchResults = searchComponents(query, allComponents);

  // Limit results
  const limitedResults = searchResults.slice(0, limit);

  // Format response
  const formattedResults = limitedResults.map(({ item, score }) => ({
    name: item.name,
    score: Math.round(score * 100),
    summary: ResponseFormatter.formatComponentOverview(item),
  }));

  const response = {
    query,
    totalResults: searchResults.length,
    showing: limitedResults.length,
    components: formattedResults,
  };

  return {
    content: [{
      type: 'text',
      text: JSON.stringify(response, null, 2),
    }],
  };
}

export const searchComponentsTool: Tool = {
  name: 'searchComponents',
  title: 'Search Components',
  description: 'Search for MDS Vue components by name, type, or functionality. Returns a list of matching components with brief descriptions.',
  inputSchema: {
    type: 'object',
    properties: {
      query: {
        type: 'string',
        description: 'Search query for components (name, type, or description)',
      },
      limit: {
        type: 'number',
        description: 'Maximum number of results to return',
        default: 10,
      },
    },
    required: ['query'],
  },
};