import type { ComponentMeta, UtilityCategory, PropInfo, EventInfo, SlotInfo } from '../types/index.js';

export class ResponseFormatter {
  
  static formatComponentOverview(component: ComponentMeta): string {
    const props = component.props?.length || 0;
    const events = component.events?.length || 0;
    const slots = component.slots?.length || 0;
    const examples = component.examples?.length || 0;
    
    return `**${component.name}** - ${props} props, ${events} events, ${slots} slots, ${examples} examples`;
  }
  
  static formatComponentDetailed(component: ComponentMeta): string {
    const sections: string[] = [];
    
    // Header
    sections.push(`# ${component.name}\n`);
    
    // Props section
    if (component.props && component.props.length > 0) {
      sections.push('## Props\n');
      for (const prop of component.props) {
        sections.push(this.formatProp(prop));
      }
      sections.push('');
    }
    
    // Events section
    if (component.events && component.events.length > 0) {
      sections.push('## Events\n');
      for (const event of component.events) {
        sections.push(this.formatEvent(event));
      }
      sections.push('');
    }
    
    // Slots section
    if (component.slots && component.slots.length > 0) {
      sections.push('## Slots\n');
      for (const slot of component.slots) {
        sections.push(this.formatSlot(slot));
      }
      sections.push('');
    }
    
    // TypeScript definition
    if (component.typescript?.content) {
      sections.push('## TypeScript Definition\n');
      sections.push('```typescript');
      sections.push(component.typescript.content);
      sections.push('```\n');
    }
    
    // Examples section
    if (component.examples && component.examples.length > 0) {
      sections.push('## Examples\n');
      for (const example of component.examples) {
        sections.push(this.formatExample(example));
      }
    }
    
    return sections.join('\n');
  }
  
  private static formatProp(prop: PropInfo): string {
    const parts: string[] = [`- **${prop.name}**`];
    
    if (prop.type) {
      parts.push(`(${prop.type})`);
    }
    
    if (prop.required) {
      parts.push('*[required]*');
    }
    
    if (prop.default !== undefined && prop.default !== null) {
      parts.push(`- Default: \`${prop.default}\``);
    }
    
    if (prop.validator) {
      parts.push('- Has custom validator');
    }
    
    return parts.join(' ');
  }
  
  private static formatEvent(event: EventInfo): string {
    const parts: string[] = [`- **${event.name}**`];
    
    if (event.payload) {
      parts.push(`- Payload: \`${event.payload}\``);
    }
    
    if (event.description) {
      parts.push(`- ${event.description}`);
    }
    
    return parts.join(' ');
  }
  
  private static formatSlot(slot: SlotInfo): string {
    const parts: string[] = [`- **${slot.name}**`];
    
    if (slot.isDefault) {
      parts.push('*[default]*');
    }
    
    if (slot.description) {
      parts.push(`- ${slot.description}`);
    }
    
    if (slot.params && slot.params.length > 0) {
      const paramsList = slot.params.map(p => `${p.name}: ${p.type}`).join(', ');
      parts.push(`- Params: (${paramsList})`);
    }
    
    return parts.join(' ');
  }
  
  private static formatExample(example: { name: string; code: string }): string {
    const sections: string[] = [];
    sections.push(`### Example: ${example.name}\n`);
    sections.push('```vue');
    sections.push(example.code.trim());
    sections.push('```\n');
    return sections.join('\n');
  }
  
  static formatUtilityCategory(utility: UtilityCategory): string {
    const sections: string[] = [];
    
    const heading = utility.title ? utility.title : utility.category;
    sections.push(`## ${heading}\n`);

    if (utility.description && utility.description.trim()) {
      sections.push(`${utility.description.trim()}\n`);
    }
    
    if (utility.classes && utility.classes.length > 0) {
      sections.push('### Classes:\n');
      
      // Group classes by prefix for better organization
      const grouped = this.groupUtilityClasses(utility.classes);
      
      for (const [prefix, classes] of Object.entries(grouped)) {
        if (prefix === 'default') {
          sections.push(classes.map(c => `- \`${c}\``).join('\n'));
        } else {
          sections.push(`\n**${prefix}:**`);
          sections.push(classes.map(c => `- \`${c}\``).join('\n'));
        }
      }
    }
    
    if (utility.examples && utility.examples.length > 0) {
      sections.push('\n### Examples:\n');
      for (const example of utility.examples) {
        const exTitle = example.title ?? example.name;
        if (exTitle) sections.push(`**${exTitle}:**`);
        if (example.description && example.description.trim()) {
          sections.push(example.description.trim());
        }
        if (example.code) {
          sections.push('```html');
          sections.push(example.code.trim());
          sections.push('```\n');
        }
      }
    }
    
    return sections.join('\n');
  }
  
  private static groupUtilityClasses(classes: string[]): Record<string, string[]> {
    const grouped: Record<string, string[]> = {};
    
    for (const className of classes) {
      // Extract prefix (e.g., mu-bg-, mu-text-, mu-p-, etc.)
      const match = className.match(/^(mu-[a-z]+(?:-[a-z]+)?)-/);
      const prefix = match ? match[1] : 'default';
      
      if (!grouped[prefix]) {
        grouped[prefix] = [];
      }
      grouped[prefix].push(className);
    }
    
    // Sort classes within each group
    for (const prefix in grouped) {
      grouped[prefix].sort();
    }
    
    return grouped;
  }
}
