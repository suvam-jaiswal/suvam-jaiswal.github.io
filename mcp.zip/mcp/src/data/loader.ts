import { promises as fs } from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

import type { ComponentMeta, UtilityCategory } from '../types/index.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export class DataLoader {
  private componentsPath: string;
  private utilitiesPath: string;
  private iconsPath: string;
  private components: Map<string, ComponentMeta> = new Map();
  private utilities: Map<string, UtilityCategory> = new Map();
  private icons: string[] = [];
  private isLoaded = false;

  constructor() {
    this.componentsPath = path.join(__dirname, '..', 'components');
    this.utilitiesPath = path.join(__dirname, '..', 'utilities.json');
    this.iconsPath = path.join(__dirname, '..', 'icons.json');
  }

  async loadAll(): Promise<void> {
    if (this.isLoaded) return;

    await this.loadComponents();
    await this.loadUtilities();
    await this.loadIcons();
    this.isLoaded = true;
  }

  private async loadComponents(): Promise<void> {
    try {
      const files = await fs.readdir(this.componentsPath);
      const jsonFiles = files.filter(f => f.endsWith('.json'));

      for (const file of jsonFiles) {
        const filePath = path.join(this.componentsPath, file);
        const content = await fs.readFile(filePath, 'utf-8');
        const componentData = JSON.parse(content) as ComponentMeta;

        if (componentData.name) {
          this.components.set(componentData.name, componentData);
        }
      }

      console.error(`Loaded ${this.components.size} components`);
    } catch (error) {
      console.error('Error loading components:', error);
      throw error;
    }
  }

  private async loadUtilities(): Promise<void> {
    try {
      const content = await fs.readFile(this.utilitiesPath, 'utf-8');
      const data = JSON.parse(content);

      if (data.utilities && Array.isArray(data.utilities)) {
        for (const utility of data.utilities) {
          if (utility.category) {
            this.utilities.set(utility.category, utility);
          }
        }
      }

      console.error(`Loaded ${this.utilities.size} utility categories`);
    } catch (error) {
      console.error('Error loading utilities:', error);
      throw error;
    }
  }

  private async loadIcons(): Promise<void> {
    try {
      const content = await fs.readFile(this.iconsPath, 'utf-8');
      const data = JSON.parse(content);

      if (data.icons && Array.isArray(data.icons)) {
        this.icons = data.icons;
      }

      console.error(`Loaded ${this.icons.length} icons`);
    } catch (error) {
      console.error('Error loading icons:', error);
      throw error;
    }
  }

  getComponent(name: string): ComponentMeta | undefined {
    return this.components.get(name);
  }

  getAllComponents(): ComponentMeta[] {
    return Array.from(this.components.values());
  }

  getComponentNames(): string[] {
    return Array.from(this.components.keys());
  }

  getUtilityCategory(category: string): UtilityCategory | undefined {
    return this.utilities.get(category);
  }

  getAllUtilities(): UtilityCategory[] {
    return Array.from(this.utilities.values());
  }

  getUtilityCategories(): string[] {
    return Array.from(this.utilities.keys());
  }

  getAllUtilityClasses(): string[] {
    const classes = new Set<string>();
    for (const utility of this.utilities.values()) {
      if (utility.classes) {
        for (const className of utility.classes) {
          classes.add(className);
        }
      }
    }
    return Array.from(classes);
  }

  getIcons(): string[] {
    return this.icons;
  }
}

export const dataLoader = new DataLoader();