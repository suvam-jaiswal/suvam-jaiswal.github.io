export type PropInfo = {
  name: string;
  type?: string;
  required?: boolean;
  default?: string | null;
  validator?: boolean;
};

export type ComponentExample = {
  name: string;
  code: string;
};

export type ComponentTsDef = {
  content: string;
} | null;

export type ComponentMeta = {
  name: string;
  props: PropInfo[];
  events: EventInfo[];
  slots: SlotInfo[];
  typescript: ComponentTsDef;
  examples: ComponentExample[];
};

export type UtilityExample = {
  name: string;
  code: string;
  classes: string[];
  title?: string;
  description?: string | null;
};

export type UtilityCategory = {
  category: string;
  examples: UtilityExample[];
  classes: string[];
  title?: string;
  description?: string | null;
};

export type LibraryMetadata = {
  package: { name: string; version: string };
  generatedAt: string;
  components: ComponentMeta[];
  utilities: UtilityCategory[];
};

export type EventInfo = {
  name: string;
  payload?: string | null;
  description?: string | null;
};

export type SlotParam = { name: string; type: string };
export type SlotInfo = { name: string; params: SlotParam[]; description?: string | null; isDefault?: boolean };

export type PrimeVueMeta = {
  props: PropInfo[];
  emits: EventInfo[];
  slots: SlotInfo[];
  typescript: string | null;
} | null;
