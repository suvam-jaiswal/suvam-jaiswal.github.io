import type { Resource } from '@modelcontextprotocol/sdk/types.js';
import { dataLoader } from '../data/loader.js';

export function createComponentCatalogResource(): Resource {
  return {
    uri: 'mds://components/catalog',
    name: 'Component Catalog',
    description: 'Complete catalog of all available MDS Vue components',
    mimeType: 'application/json',
  };
}

export async function getComponentCatalog() {
  const components = dataLoader.getAllComponents();
  
  // Group components by category based on name patterns
  const categorized: Record<string, string[]> = {
    'Form': [],
    'Data': [],
    'Overlay': [],
    'Navigation': [],
    'Display': [],
    'Feedback': [],
    'Media': [],
    'Misc': [],
  };
  
  for (const component of components) {
    const name = component.name;
    let category = 'Misc';
    
    // Categorize based on component name patterns
    if (/^(Input|Select|Checkbox|Radio|Text|Form|DatePicker|Calendar|ColorPicker|Slider|Rating|Knob|Switch|ToggleButton|TriStateCheckbox)/i.test(name)) {
      category = 'Form';
    } else if (/^(DataTable|DataView|Tree|TreeTable|TreeSelect|OrderList|PickList|Timeline|VirtualScroller|Paginator)/i.test(name)) {
      category = 'Data';
    } else if (/^(Dialog|Drawer|ConfirmDialog|ConfirmPopup|OverlayPanel|Sidebar|Tooltip|Popover)/i.test(name)) {
      category = 'Overlay';
    } else if (/^(Menu|MenuBar|Breadcrumb|Steps|TabMenu|TieredMenu|ContextMenu|Dock|MegaMenu|PanelMenu|TabView|NavigationHeader)/i.test(name)) {
      category = 'Navigation';
    } else if (/^(Card|Panel|Fieldset|Accordion|ScrollPanel|Splitter|Stepper|Divider|Toolbar|ScrollTop)/i.test(name)) {
      category = 'Display';
    } else if (/^(Message|Toast|InlineMessage|MessagesBox|ProgressBar|ProgressSpinner|Skeleton|BlockUI|Badge|Chip|Tag|Avatar|AvatarGroup)/i.test(name)) {
      category = 'Feedback';
    } else if (/^(Image|Galleria|Carousel|Chart)/i.test(name)) {
      category = 'Media';
    }
    
    categorized[category].push(name);
  }
  
  // Sort categories and component names
  for (const category of Object.keys(categorized)) {
    categorized[category].sort();
  }
  
  const catalog = {
    totalComponents: components.length,
    categories: categorized,
    allComponents: components.map(c => ({
      name: c.name,
      propsCount: c.props?.length || 0,
      eventsCount: c.events?.length || 0,
      slotsCount: c.slots?.length || 0,
      examplesCount: c.examples?.length || 0,
    })),
  };
  
  return {
    contents: [{
      uri: 'mds://components/catalog',
      mimeType: 'application/json',
      text: JSON.stringify(catalog, null, 2),
    }],
  };
}