import type { Resource } from '@modelcontextprotocol/sdk/types.js';
import { dataLoader } from '../data/loader.js';
import { ResponseFormatter } from '../data/formatter.js';

export function createComponentDetailResources(): Resource[] {
  const components = dataLoader.getComponentNames();
  
  return components.map(name => ({
    uri: `mds://components/${name}`,
    name: `${name} Component`,
    description: `Detailed documentation for the ${name} component`,
    mimeType: 'text/markdown',
  }));
}

export async function getComponentDetail(componentName: string) {
  const component = dataLoader.getComponent(componentName);
  
  if (!component) {
    return {
      contents: [{
        uri: `mds://components/${componentName}`,
        mimeType: 'text/plain',
        text: `Component "${componentName}" not found`,
      }],
    };
  }
  
  const documentation = ResponseFormatter.formatComponentDetailed(component);
  
  return {
    contents: [{
      uri: `mds://components/${componentName}`,
      mimeType: 'text/markdown',
      text: documentation,
    }],
  };
}