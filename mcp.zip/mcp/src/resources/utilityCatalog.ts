import type { Resource } from '@modelcontextprotocol/sdk/types.js';
import { dataLoader } from '../data/loader.js';
import { ResponseFormatter } from '../data/formatter.js';

export function createUtilityCatalogResource(): Resource {
  return {
    uri: 'mds://utilities/catalog',
    name: 'Utility Classes Catalog',
    description: 'Complete catalog of all MDS utility classes organized by category',
    mimeType: 'text/markdown',
  };
}

export async function getUtilityCatalog() {
  const utilities = dataLoader.getAllUtilities();
  
  const sections: string[] = ['# MDS Utility Classes Catalog\n'];
  
  // Create table of contents
  sections.push('## Table of Contents\n');
  for (const utility of utilities) {
    sections.push(`- [${utility.category}](#${utility.category.toLowerCase().replace(/\s+/g, '-')})`);
  }
  sections.push('\n');
  
  // Add each category
  for (const utility of utilities) {
    sections.push(ResponseFormatter.formatUtilityCategory(utility));
    sections.push('\n---\n');
  }
  
  // Add summary
  const totalClasses = dataLoader.getAllUtilityClasses().length;
  sections.push(`## Summary\n`);
  sections.push(`- **Total Categories**: ${utilities.length}`);
  sections.push(`- **Total Utility Classes**: ${totalClasses}`);
  
  return {
    contents: [{
      uri: 'mds://utilities/catalog',
      mimeType: 'text/markdown',
      text: sections.join('\n'),
    }],
  };
}