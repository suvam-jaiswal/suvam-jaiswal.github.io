export function fuzzyMatch(query: string, target: string): number {
  const q = query.toLowerCase();
  const t = target.toLowerCase();
  
  // Exact match
  if (t === q) return 1.0;
  
  // Contains exact query
  if (t.includes(q)) return 0.8;
  
  // All characters in query are in target in order
  let queryIndex = 0;
  let targetIndex = 0;
  let matchCount = 0;
  
  while (queryIndex < q.length && targetIndex < t.length) {
    if (q[queryIndex] === t[targetIndex]) {
      matchCount++;
      queryIndex++;
    }
    targetIndex++;
  }
  
  if (matchCount === q.length) {
    // All characters found in order
    return 0.6 + (0.2 * (1 - (t.length - q.length) / t.length));
  }
  
  // Partial match based on common characters
  const commonChars = countCommonChars(q, t);
  return commonChars / Math.max(q.length, t.length) * 0.5;
}

function countCommonChars(s1: string, s2: string): number {
  const chars1 = new Map<string, number>();
  const chars2 = new Map<string, number>();
  
  for (const char of s1) {
    chars1.set(char, (chars1.get(char) || 0) + 1);
  }
  
  for (const char of s2) {
    chars2.set(char, (chars2.get(char) || 0) + 1);
  }
  
  let common = 0;
  for (const [char, count] of chars1) {
    const count2 = chars2.get(char) || 0;
    common += Math.min(count, count2);
  }
  
  return common;
}

interface SearchableComponent {
  name: string;
  description?: string;
}

export function searchComponents<T extends SearchableComponent>(query: string, components: T[], threshold = 0.3): Array<{ item: T; score: number }> {
  const results: Array<{ item: T; score: number }> = [];
  
  for (const component of components) {
    let score = 0;
    
    // Match against name
    const nameScore = fuzzyMatch(query, component.name);
    score = Math.max(score, nameScore);
    
    // Match against description if available
    if (component.description) {
      const descScore = fuzzyMatch(query, component.description) * 0.7; // Lower weight for description
      score = Math.max(score, descScore);
    }
    
    // Check for semantic matches
    const semanticScore = getSemanticScore(query, component.name);
    score = Math.max(score, semanticScore);
    
    if (score >= threshold) {
      results.push({ item: component, score });
    }
  }
  
  // Sort by score descending
  return results.sort((a, b) => b.score - a.score);
}

function getSemanticScore(query: string, componentName: string): number {
  const q = query.toLowerCase();
  const name = componentName.toLowerCase();
  
  // Define semantic mappings
  const semanticMap: Record<string, string[]> = {
    'modal': ['dialog', 'drawer', 'popover', 'overlay'],
    'popup': ['dialog', 'popover', 'tooltip', 'overlay'],
    'dropdown': ['select', 'autocomplete', 'menu', 'listbox'],
    'input': ['inputtext', 'textarea', 'inputnumber', 'inputmask'],
    'list': ['datatable', 'dataview', 'listbox', 'tree'],
    'navigation': ['menu', 'menubar', 'breadcrumb', 'steps', 'tabmenu'],
    'form': ['input', 'select', 'checkbox', 'radio', 'textarea'],
    'button': ['button', 'splitbutton', 'speeddial'],
    'card': ['card', 'panel', 'fieldset', 'accordion'],
    'tabs': ['tabview', 'tabmenu', 'accordion'],
    'alert': ['message', 'toast', 'inlinemessage'],
    'progress': ['progressbar', 'progressspinner', 'skeleton'],
    'loading': ['progressspinner', 'skeleton', 'blockui'],
  };
  
  for (const [keyword, relatedComponents] of Object.entries(semanticMap)) {
    if (q.includes(keyword)) {
      for (const related of relatedComponents) {
        if (name.includes(related)) {
          return 0.7; // High score for semantic match
        }
      }
    }
  }
  
  return 0;
}

interface SearchableUtility {
  category: string;
  classes: string[];
}

export function searchUtilities<T extends SearchableUtility>(query: string, utilities: T[], threshold = 0.3): Array<{ item: T; score: number }> {
  const results: Array<{ item: T; score: number }> = [];
  const q = query.toLowerCase();
  
  for (const utility of utilities) {
    let score = 0;
    
    // Match against category
    const categoryScore = fuzzyMatch(query, utility.category);
    score = Math.max(score, categoryScore);
    
    // Match against class names
    for (const className of utility.classes) {
      const classScore = fuzzyMatch(query, className) * 0.8;
      score = Math.max(score, classScore);
      
      // Check if query matches utility prefix patterns
      if (className.startsWith('mu-') && className.includes(q.replace(/[\s-]/g, ''))) {
        score = Math.max(score, 0.7);
      }
    }
    
    if (score >= threshold) {
      results.push({ item: utility, score });
    }
  }
  
  return results.sort((a, b) => b.score - a.score);
}