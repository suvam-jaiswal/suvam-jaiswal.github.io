import { z } from 'zod';
import type { Prompt } from '@modelcontextprotocol/sdk/types.js';
import { dataLoader } from '../data/loader.js';
import { ResponseFormatter } from '../data/formatter.js';

export const buildComponentInputSchema = z.object({
  requirements: z.string().describe('Description of the component requirements'),
  components: z.array(z.string()).optional().describe('Specific components to use (optional)'),
  includeUtilities: z.boolean().optional().default(true).describe('Whether to include utility classes'),
});

export type BuildComponentInput = z.infer<typeof buildComponentInputSchema>;

export function createBuildComponentPrompt(input: BuildComponentInput) {
  const { requirements, components, includeUtilities } = input;
  
  const messages: Array<{ role: string; content: { type: string; text: string } }> = [];
  
  // System message with MDS context
  let systemMessage = `You are an expert Vue.js developer working with the Mosaic Design System (MDS) component library.
  
Your task is to build a Vue component that meets the following requirements:
${requirements}

Guidelines:
1. Use MDS Vue components from the library
2. Follow Vue 3 Composition API patterns
3. Use TypeScript for type safety
4. Apply MDS utility classes for styling
5. Ensure accessibility compliance
6. Write clean, maintainable code`;

  // Add specific component documentation if requested
  if (components && components.length > 0) {
    systemMessage += '\n\n## Available Components Documentation:\n';
    
    for (const componentName of components) {
      const component = dataLoader.getComponent(componentName);
      if (component) {
        systemMessage += '\n' + ResponseFormatter.formatComponentDetailed(component);
      }
    }
  }
  
  // Add utility classes reference if requested
  if (includeUtilities) {
    systemMessage += '\n\n## Common Utility Classes:\n';
    systemMessage += '- Spacing: mu-p-{0-10}, mu-m-{0-10}\n';
    systemMessage += '- Flex: mu-d-flex, mu-flex-column, mu-align-items-center, mu-justify-content-between\n';
    systemMessage += '- Grid: mu-grid, mu-col-{1-12}\n';
    systemMessage += '- Text: mu-text-{size}, mu-font-weight-{weight}\n';
    systemMessage += '- Background: mu-bg-{color}\n';
    systemMessage += '- Borders: mu-border, mu-border-radius-{size}\n';
  }
  
  messages.push({
    role: 'system',
    content: {
      type: 'text',
      text: systemMessage,
    },
  });
  
  messages.push({
    role: 'user',
    content: {
      type: 'text',
      text: `Build a Vue component that satisfies these requirements: ${requirements}\n\nProvide the complete component code with proper imports, template, script setup, and any necessary styles.`,
    },
  });
  
  return {
    messages,
  };
}

export const buildComponentPrompt: Prompt = {
  name: 'buildComponent',
  title: 'Build Component',
  description: 'Generate a complete Vue component implementation using MDS components',
  arguments: [
    {
      name: 'requirements',
      description: 'Description of the component requirements',
      required: true,
    },
    {
      name: 'components',
      description: 'Specific components to use (optional)',
      required: false,
    },
    {
      name: 'includeUtilities',
      description: 'Whether to include utility classes',
      required: false,
    },
  ],
};