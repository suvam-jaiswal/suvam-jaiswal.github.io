#!/usr/bin/env node

import { Server } from '@modelcontextprotocol/sdk/server/index.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import {
  CallToolRequestSchema,
  ListToolsRequestSchema,
  ListResourcesRequestSchema,
  ReadResourceRequestSchema,
  ListPromptsRequestSchema,
  GetPromptRequestSchema,
} from '@modelcontextprotocol/sdk/types.js';

// Import data loader
import { dataLoader } from './src/data/loader.js';

// Import tools
import { searchComponentsTool, handleSearchComponents, type SearchComponentsInput } from './src/tools/searchComponents.js';
import { getComponentDocsTool, handleGetComponentDocs, type GetComponentDocsInput } from './src/tools/getComponentDocs.js';
import { searchUtilitiesTool, handleSearchUtilities, type SearchUtilitiesInput } from './src/tools/searchUtilities.js';
import { getIconsTool, handleGetIcons, type GetIconsInput } from './src/tools/getIcons.js';
import { listComponentsTool, handleListComponents } from './src/tools/listComponents.js';

// Import resources
import { createComponentCatalogResource, getComponentCatalog } from './src/resources/componentCatalog.js';
import { createComponentDetailResources, getComponentDetail } from './src/resources/componentDetail.js';
import { createUtilityCatalogResource, getUtilityCatalog } from './src/resources/utilityCatalog.js';

// Import prompts
import { buildComponentPrompt, createBuildComponentPrompt, type BuildComponentInput } from './src/prompts/buildComponent.js';

class PlatformUIServer {
  private server: Server;

  constructor() {
    this.server = new Server(
      {
        name: 'platform-ui-mcp-server',
        version: '1.0.0',
      },
      {
        capabilities: {
          tools: {},
          resources: {},
          prompts: {},
        },
      }
    );

    this.setupHandlers();
  }

  private setupHandlers() {
    // Tool handlers
    this.server.setRequestHandler(ListToolsRequestSchema, async () => ({
      tools: [
        searchComponentsTool,
        getComponentDocsTool,
        searchUtilitiesTool,
        getIconsTool,
        listComponentsTool,
      ],
    }));

    this.server.setRequestHandler(CallToolRequestSchema, async (request) => {
      const { name, arguments: args } = request.params;

      switch (name) {
        case 'searchComponents':
          return handleSearchComponents(args as unknown as SearchComponentsInput);
        case 'getComponentDocs':
          return handleGetComponentDocs(args as unknown as GetComponentDocsInput);
        case 'searchUtilities':
          return handleSearchUtilities(args as unknown as SearchUtilitiesInput);
        case 'getIcons':
          return handleGetIcons(args as unknown as GetIconsInput);
        case 'listComponents':
          return handleListComponents();
        default:
          return {
            content: [{
              type: 'text',
              text: `Unknown tool: ${name}`,
            }],
            isError: true,
          };
      }
    });

    // Resource handlers
    this.server.setRequestHandler(ListResourcesRequestSchema, async () => {
      const resources = [
        createComponentCatalogResource(),
        ...createComponentDetailResources(),
        createUtilityCatalogResource(),
      ];

      return { resources };
    });

    this.server.setRequestHandler(ReadResourceRequestSchema, async (request) => {
      const { uri } = request.params;

      if (uri === 'mds://components/catalog') {
        return getComponentCatalog();
      } else if (uri === 'mds://utilities/catalog') {
        return getUtilityCatalog();
      } else if (uri.startsWith('mds://components/')) {
        const componentName = uri.replace('mds://components/', '');
        return getComponentDetail(componentName);
      }

      return {
        contents: [{
          uri,
          mimeType: 'text/plain',
          text: `Resource not found: ${uri}`,
        }],
      };
    });

    // Prompt handlers
    this.server.setRequestHandler(ListPromptsRequestSchema, async () => ({
      prompts: [buildComponentPrompt],
    }));

    this.server.setRequestHandler(GetPromptRequestSchema, async (request) => {
      const { name, arguments: args } = request.params;

      if (name === 'buildComponent') {
        return createBuildComponentPrompt(args as unknown as BuildComponentInput);
      }

      throw new Error(`Unknown prompt: ${name}`);
    });
  }

  async start() {
    // Load all data at startup
    console.error('Loading MDS component and utility data...');
    await dataLoader.loadAll();
    console.error('Data loading complete!');

    // Connect to stdio transport
    const transport = new StdioServerTransport();
    await this.server.connect(transport);
    console.error('Platform UI MCP Server running on stdio');
  }
}

async function main() {
  try {
    const server = new PlatformUIServer();
    await server.start();
  } catch (error) {
    console.error('Fatal error running server:', error);
    process.exit(1);
  }
}

main();
